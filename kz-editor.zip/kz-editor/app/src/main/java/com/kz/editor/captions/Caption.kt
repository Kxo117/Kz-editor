package com.kz.editor.captions

/**
 * text: first line = white, remaining lines = accent blue + bold
 * (same look as the reference video). Amharic (Ethiopic) text works with the system font.
 */
data class Caption(val startMs: Long, val endMs: Long, val text: String)
