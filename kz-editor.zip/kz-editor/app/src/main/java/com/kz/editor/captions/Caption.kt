package com.kz.editor.captions

/**
 * text: first line = color 1 (white), remaining lines = color 2 (accent) + bold.
 * Amharic (Ethiopic) text works with the system font.
 */
data class Caption(val startMs: Long, val endMs: Long, val text: String)

enum class CaptionStyle(val label: String, val c1: Long, val c2: Long) {
    Classic("Classic Blue", 0xFFFFFFFF, 0xFF2D5BFF),
    Yellow("Yellow", 0xFFFFFFFF, 0xFFFFD400),
    Neon("Neon Pink", 0xFFFFFFFF, 0xFFFF2D95),
    Green("Green", 0xFFFFFFFF, 0xFF21E06B)
}
