package com.kz.editor.effects

/** All values that drive the one-pass GPU shader (UberEffect). */
class FxParams {
    var bright = 0f
    var contrast = 1f
    var sat = 1f
    var warm = 0f
    var tint = 0f
    var sharp = 0f
    var denoise = 0f
    var vignette = 0f
    var grain = 0f
    var blur = 0f
    var chroma = 0f
    var pixel = 0f
    var glitch = 0f
    var mirror = 0f
    var vhs = 0f
    var bloom = 0f
    var colorMode = 0f
    var motion = 0f
    var transIn = 0f
    var transOut = 0f
    var transLen = 0.7f
    var dur = 1f

    fun toMap(): Map<String, Float> = mapOf(
        "uBright" to bright, "uContrast" to contrast, "uSat" to sat, "uWarm" to warm,
        "uTint" to tint, "uSharp" to sharp, "uDenoise" to denoise, "uVignette" to vignette,
        "uGrain" to grain, "uBlur" to blur, "uChroma" to chroma, "uPixel" to pixel,
        "uGlitch" to glitch, "uMirror" to mirror, "uVhs" to vhs, "uBloom" to bloom,
        "uColorMode" to colorMode, "uMotion" to motion, "uTransIn" to transIn,
        "uTransOut" to transOut, "uTransLen" to transLen, "uDur" to dur
    )
}

/** Looks / Visual Enhancer presets. */
enum class EnhancerPreset(val label: String, val apply: (FxParams) -> Unit) {
    Original("Original", { }),
    Hdr("HDR", { p -> p.contrast = 1.18f; p.sat = 1.22f; p.sharp = 0.35f; p.bloom = 0.1f }),
    Clear("Clear", { p -> p.contrast = 1.06f; p.sharp = 0.45f }),
    UltraClear("Ultra Clear", { p -> p.contrast = 1.12f; p.sat = 1.08f; p.sharp = 0.9f; p.denoise = 0.2f }),
    ArcticBlue("Arctic Blue", { p -> p.warm = -1.2f; p.contrast = 1.08f; p.sharp = 0.3f }),
    WarmGlow("Warm Glow", { p -> p.warm = 1.2f; p.bright = 0.02f; p.bloom = 0.15f; p.sharp = 0.2f }),
    Cinematic("Cinematic", { p -> p.colorMode = 7f; p.contrast = 1.15f; p.vignette = 0.3f; p.sharp = 0.25f }),
    Vivid("Vivid", { p -> p.sat = 1.4f; p.contrast = 1.1f; p.sharp = 0.3f }),
    Moody("Moody", { p -> p.contrast = 1.2f; p.sat = 0.8f; p.bright = -0.04f; p.vignette = 0.45f }),
    Pastel("Pastel", { p -> p.contrast = 0.9f; p.sat = 0.85f; p.bright = 0.06f }),
    Noir("Noir", { p -> p.colorMode = 1f; p.contrast = 1.3f; p.vignette = 0.4f; p.grain = 0.3f }),
    Sunset("Sunset", { p -> p.warm = 1.8f; p.sat = 1.2f; p.tint = 0.3f; p.bloom = 0.2f })
}

/** Creative effects (CapCut / After Effects style). */
enum class StyleEffect(val label: String, val apply: (FxParams) -> Unit) {
    None("None", { }),
    Glitch("Glitch", { p -> p.glitch = 1f; p.chroma = 0.002f }),
    RgbSplit("RGB Split", { p -> p.chroma = 0.006f }),
    Vhs("VHS", { p -> p.vhs = 1f; p.grain = 0.2f }),
    FilmGrain("Film Grain", { p -> p.grain = 0.6f }),
    Vignette("Vignette", { p -> p.vignette = 0.7f }),
    Blur("Blur", { p -> p.blur = 1.5f }),
    Pixelate("Pixelate", { p -> p.pixel = 16f }),
    Mirror("Mirror", { p -> p.mirror = 1f }),
    MirrorV("Mirror V", { p -> p.mirror = 2f }),
    Quad("Quad Mirror", { p -> p.mirror = 3f }),
    Glow("Glow", { p -> p.bloom = 1f }),
    BlackWhite("B&W", { p -> p.colorMode = 1f }),
    Sepia("Sepia", { p -> p.colorMode = 2f }),
    Invert("Invert", { p -> p.colorMode = 3f }),
    Duotone("Duotone", { p -> p.colorMode = 4f }),
    Cyberpunk("Cyberpunk", { p -> p.colorMode = 5f; p.chroma = 0.002f; p.bloom = 0.4f }),
    Vintage("Vintage", { p -> p.colorMode = 6f; p.grain = 0.25f; p.vignette = 0.3f })
}

/** Camera-style motion (After Effects keyframe style). */
enum class Motion(val label: String, val id: Float) {
    None("None", 0f),
    ZoomIn("Zoom In", 1f),
    ZoomOut("Zoom Out", 2f),
    Pulse("Pulse", 3f),
    Shake("Shake", 4f),
    Drift("Drift", 5f)
}

/** Intro / outro transitions. */
enum class Transition(val label: String, val id: Float) {
    None("None", 0f),
    Fade("Fade", 1f),
    FadeWhite("Fade White", 2f),
    Wipe("Wipe", 3f),
    Zoom("Zoom", 4f),
    Glitch("Glitch", 5f),
    Flash("Flash", 6f),
    Blur("Blur", 7f),
    Iris("Iris", 8f),
    Pixelate("Pixelate", 9f)
}
