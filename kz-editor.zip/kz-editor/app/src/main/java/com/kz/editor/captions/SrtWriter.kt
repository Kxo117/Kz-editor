package com.kz.editor.captions

object SrtWriter {
    fun write(captions: List<Caption>): String = buildString {
        captions.sortedBy { it.startMs }.forEachIndexed { i, c ->
            append(i + 1).append('\n')
            append(fmt(c.startMs)).append(" --> ").append(fmt(c.endMs)).append('\n')
            append(c.text).append("\n\n")
        }
    }

    private fun fmt(ms: Long): String {
        val h = ms / 3_600_000
        val m = ms / 60_000 % 60
        val s = ms / 1000 % 60
        val r = ms % 1000
        return "%02d:%02d:%02d,%03d".format(h, m, s, r)
    }
}
