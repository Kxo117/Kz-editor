package com.kz.editor.data

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import org.json.JSONArray
import org.json.JSONObject

data class Recent(val uri: String, val name: String, val ts: Long, val durMs: Long)

/** Remembers recently opened videos (not editing state). */
object ProjectStore {
    private const val PREFS = "kz_projects"
    private const val KEY = "recent"

    fun load(ctx: Context): List<Recent> {
        val s = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, null)
            ?: return emptyList()
        return try {
            val a = JSONArray(s)
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                Recent(o.getString("uri"), o.getString("name"), o.getLong("ts"), o.getLong("dur"))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun add(ctx: Context, r: Recent) {
        val list = (listOf(r) + load(ctx).filter { it.uri != r.uri }).take(30)
        val a = JSONArray()
        list.forEach {
            a.put(JSONObject().put("uri", it.uri).put("name", it.name).put("ts", it.ts).put("dur", it.durMs))
        }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, a.toString()).apply()
    }

    fun displayName(ctx: Context, uri: Uri): String {
        try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) return c.getString(0) ?: "video"
            }
        } catch (e: Exception) {
        }
        return "video"
    }
}
