package com.kz.editor.ui

import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kz.editor.data.Recent
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val INK = Color(0xFF111111)
private val CARD = Brush.linearGradient(listOf(Color(0xFFA8E0FB), Color(0xFF6CC6F0)))

@Composable
fun HomeScreen(
    recents: List<Recent>,
    onNew: () -> Unit,
    onTool: (Tool) -> Unit,
    onOpenRecent: (Recent) -> Unit
) {
    Box(
        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFFE4FAFF), Color.White)))
    ) {
        LazyColumn(Modifier.fillMaxSize().padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            item {
                Spacer(Modifier.height(36.dp))
                Text("kz editor", color = INK, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(12.dp))
                Row(Modifier.fillMaxWidth().height(130.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    BigCard("＋", "New video", Modifier.weight(1.2f), onNew)
                    BigCard("HD", "Enhance video", Modifier.weight(1f)) { onTool(Tool.Enhance) }
                }
                Spacer(Modifier.height(12.dp))
                TileRow(listOf(Tool.Edit, Tool.Audio, Tool.Text, Tool.Effects), onTool)
                Spacer(Modifier.height(8.dp))
                TileRow(listOf(Tool.Captions, Tool.Filters, Tool.Adjust, Tool.Enhance), onTool)
                Spacer(Modifier.height(16.dp))
                Text("Recent videos", color = INK, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                if (recents.isEmpty()) {
                    Text("Nothing yet — tap New video", color = Color.Gray, fontSize = 14.sp)
                }
            }
            items(recents) { r -> RecentRow(r, onOpenRecent) }
            item { Spacer(Modifier.height(24.dp)) }
        }
    }
}

@Composable
private fun BigCard(glyph: String, label: String, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier.fillMaxHeight().clip(RoundedCornerShape(20.dp)).background(CARD).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(glyph, color = INK, fontSize = 30.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text(label, color = INK, fontSize = 18.sp, fontWeight = FontWeight.Medium)
        }
    }
}

@Composable
private fun TileRow(tools: List<Tool>, onTool: (Tool) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        tools.forEach { t ->
            Column(
                Modifier.weight(1f).clickable { onTool(t) },
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    Modifier.fillMaxWidth().height(64.dp).clip(RoundedCornerShape(16.dp)).background(Color(0xFFF1F3F5)),
                    contentAlignment = Alignment.Center
                ) { Text(t.glyph, color = INK, fontSize = 22.sp, fontWeight = FontWeight.Bold) }
                Spacer(Modifier.height(4.dp))
                Text(t.label, color = INK, fontSize = 13.sp)
            }
        }
    }
}

@Composable
private fun RecentRow(r: Recent, onOpen: (Recent) -> Unit) {
    val ctx = LocalContext.current
    val bmp by produceState<Bitmap?>(null, r.uri) {
        value = withContext(Dispatchers.IO) {
            try {
                val m = MediaMetadataRetriever()
                m.setDataSource(ctx, Uri.parse(r.uri))
                val b = m.getFrameAtTime(0)
                m.release()
                b
            } catch (e: Exception) {
                null
            }
        }
    }
    Row(
        Modifier.fillMaxWidth().clickable { onOpen(r) }.padding(vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(width = 78.dp, height = 78.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFFDDDDDD))) {
            bmp?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
        }
        Spacer(Modifier.width(14.dp))
        Column {
            Text(r.name, color = INK, fontSize = 17.sp, fontWeight = FontWeight.Medium, maxLines = 1)
            Text(
                SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.getDefault()).format(Date(r.ts)),
                color = Color.Gray, fontSize = 13.sp
            )
            Text("%02d:%02d".format(r.durMs / 60000, r.durMs / 1000 % 60), color = Color.Gray, fontSize = 13.sp)
        }
    }
}
