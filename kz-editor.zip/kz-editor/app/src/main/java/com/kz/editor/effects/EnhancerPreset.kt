package com.kz.editor.effects

import androidx.media3.common.Effect
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.Brightness
import androidx.media3.effect.Contrast
import androidx.media3.effect.HslAdjustment
import androidx.media3.effect.RgbAdjustment

/** Visual Enhancer presets (same list as the reference screenshot). */
@UnstableApi
enum class EnhancerPreset(val label: String) {
    Original("Original"),
    Hdr("HDR"),
    Clear("Clear"),
    UltraClear("Ultra Clear"),
    ArcticBlue("Arctic Blue"),
    WarmGlow("Warm Glow"),
    Cinematic("Cinematic");

    fun effects(): List<Effect> = when (this) {
        Original -> emptyList()
        Hdr -> listOf(
            Contrast(0.22f),
            HslAdjustment.Builder().adjustSaturation(22f).build(),
            SharpenEffect(0.35f)
        )
        Clear -> listOf(Contrast(0.08f), SharpenEffect(0.45f))
        UltraClear -> listOf(
            Contrast(0.14f),
            HslAdjustment.Builder().adjustSaturation(10f).build(),
            SharpenEffect(0.85f)
        )
        ArcticBlue -> listOf(
            RgbAdjustment.Builder().setRedScale(0.90f).setBlueScale(1.12f).build(),
            Contrast(0.08f),
            SharpenEffect(0.30f)
        )
        WarmGlow -> listOf(
            RgbAdjustment.Builder().setRedScale(1.08f).setBlueScale(0.90f).build(),
            Brightness(0.03f),
            SharpenEffect(0.20f)
        )
        Cinematic -> listOf(
            Contrast(0.20f),
            HslAdjustment.Builder().adjustSaturation(-12f).build(),
            RgbAdjustment.Builder().setRedScale(1.04f).setBlueScale(0.97f).build(),
            SharpenEffect(0.25f)
        )
    }
}
