package com.kz.editor.ui

import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.util.UnstableApi
import com.kz.editor.EditorViewModel
import com.kz.editor.data.ProjectStore
import com.kz.editor.data.Recent

@UnstableApi
@Composable
fun AppRoot(vm: EditorViewModel = viewModel()) {
    val ctx = LocalContext.current
    var inEditor by remember { mutableStateOf(false) }
    var startTool by remember { mutableStateOf<Tool?>(null) }
    var pendingTool by remember { mutableStateOf<Tool?>(null) }
    var recents by remember { mutableStateOf(ProjectStore.load(ctx)) }

    fun open(uri: Uri, tool: Tool?) {
        try {
            vm.onVideoPicked(uri)
            ProjectStore.add(
                ctx,
                Recent(uri.toString(), ProjectStore.displayName(ctx, uri), System.currentTimeMillis(), vm.state.value.durationMs)
            )
            recents = ProjectStore.load(ctx)
            startTool = tool
            inEditor = true
        } catch (e: Exception) {
            Toast.makeText(ctx, "Can't open this video", Toast.LENGTH_SHORT).show()
        }
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            try {
                ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {
            }
            open(uri, pendingTool)
        }
    }

    BackHandler(enabled = inEditor) { inEditor = false }

    if (inEditor) {
        EditorScreen(startTool = startTool, onClose = { inEditor = false })
    } else {
        HomeScreen(
            recents = recents,
            onNew = { pendingTool = null; picker.launch(arrayOf("video/*")) },
            onTool = { t -> pendingTool = t; picker.launch(arrayOf("video/*")) },
            onOpenRecent = { r -> open(Uri.parse(r.uri), null) }
        )
    }
}
