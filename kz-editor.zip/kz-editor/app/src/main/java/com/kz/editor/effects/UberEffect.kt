package com.kz.editor.effects

import android.content.Context
import android.opengl.GLES20
import androidx.media3.common.VideoFrameProcessingException
import androidx.media3.common.util.GlProgram
import androidx.media3.common.util.GlUtil
import androidx.media3.common.util.Size
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.BaseGlShaderProgram
import androidx.media3.effect.GlEffect
import androidx.media3.effect.GlShaderProgram

/** One-pass GPU effect: color, sharpen, denoise, blur, glitch, VHS, bloom, motion, transitions. */
@UnstableApi
class UberEffect(private val params: Map<String, Float>) : GlEffect {
    override fun toGlShaderProgram(context: Context, useHdr: Boolean): GlShaderProgram =
        UberProgram(params, useHdr)
}

@UnstableApi
private class UberProgram(private val params: Map<String, Float>, useHdr: Boolean) :
    BaseGlShaderProgram(useHdr, 1) {

    private val program: GlProgram = try {
        GlProgram(VERTEX, FRAGMENT)
    } catch (e: Exception) {
        throw VideoFrameProcessingException(e)
    }
    private var texelW = 0f
    private var texelH = 0f

    init {
        try {
            program.setBufferAttribute(
                "aFramePosition",
                GlUtil.getNormalizedCoordinateBounds(),
                GlUtil.HOMOGENEOUS_COORDINATE_VECTOR_SIZE
            )
        } catch (e: Exception) {
            throw VideoFrameProcessingException(e)
        }
    }

    override fun configure(inputWidth: Int, inputHeight: Int): Size {
        texelW = 1f / inputWidth
        texelH = 1f / inputHeight
        return Size(inputWidth, inputHeight)
    }

    private fun setF(name: String, value: Float) {
        try {
            program.setFloatUniform(name, value)
        } catch (e: Exception) {
            // uniform optimized out by the GLSL compiler: ignore
        }
    }

    override fun drawFrame(inputTexId: Int, presentationTimeUs: Long) {
        try {
            program.use()
            program.setSamplerTexIdUniform("uTexSampler", inputTexId, 0)
            program.setFloatsUniform("uTexel", floatArrayOf(texelW, texelH))
            setF("uTime", presentationTimeUs / 1_000_000f)
            for ((k, v) in params) setF(k, v)
            program.bindAttributesAndUniforms()
            GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4)
        } catch (e: GlUtil.GlException) {
            throw VideoFrameProcessingException(e, presentationTimeUs)
        }
    }

    override fun release() {
        super.release()
        try {
            program.delete()
        } catch (e: GlUtil.GlException) {
            throw VideoFrameProcessingException(e)
        }
    }

    companion object {
        private const val VERTEX = """
attribute vec4 aFramePosition;
varying vec2 vTexSamplingCoord;
void main() {
  gl_Position = aFramePosition;
  vTexSamplingCoord = aFramePosition.xy * 0.5 + 0.5;
}
"""
        private const val FRAGMENT = """
#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
uniform sampler2D uTexSampler;
uniform vec2 uTexel;
uniform float uTime, uDur;
uniform float uBright, uContrast, uSat, uWarm, uTint, uSharp, uDenoise, uVignette, uGrain;
uniform float uBlur, uChroma, uPixel, uGlitch, uMirror, uVhs, uBloom, uColorMode, uMotion;
uniform float uTransIn, uTransOut, uTransLen;
varying vec2 vTexSamplingCoord;

float hash(vec2 p) { return fract(sin(dot(p, vec2(12.9898, 78.233))) * 43758.5453); }
vec3 tex(vec2 uv) { return texture2D(uTexSampler, clamp(uv, 0.0, 1.0)).rgb; }

void main() {
  vec2 uv = vTexSamplingCoord;
  float t = uTime;

  // ---- transition progress (p: 0 hidden -> 1 shown) ----
  float tt = 0.0;
  float p = 1.0;
  if (uTransIn > 0.5 && t < uTransLen) {
    tt = floor(uTransIn + 0.5);
    p = clamp(t / uTransLen, 0.0, 1.0);
  } else if (uTransOut > 0.5 && t > uDur - uTransLen) {
    tt = floor(uTransOut + 0.5);
    p = clamp((uDur - t) / uTransLen, 0.0, 1.0);
  }
  p = p * p * (3.0 - 2.0 * p);
  float q = 1.0 - p;

  float blurAmt = uBlur;
  float pixAmt = uPixel;
  float glitchAmt = uGlitch;
  if (tt == 7.0) blurAmt += q * 8.0;
  if (tt == 9.0) pixAmt = max(pixAmt, q * 80.0);
  if (tt == 5.0) glitchAmt += q * 2.0;

  // ---- motion ----
  float mo = floor(uMotion + 0.5);
  float prog = clamp(t / max(uDur, 0.001), 0.0, 1.0);
  float zoom = 1.0;
  vec2 off = vec2(0.0);
  if (mo == 1.0) zoom = 1.0 + 0.18 * prog;
  else if (mo == 2.0) zoom = 1.18 - 0.18 * prog;
  else if (mo == 3.0) zoom = 1.0 + 0.06 * abs(sin(t * 9.4248));
  else if (mo == 4.0) { zoom = 1.04; off = 0.008 * vec2(sin(t * 53.0), cos(t * 47.0)); }
  else if (mo == 5.0) { zoom = 1.1; off = vec2((prog - 0.5) * 0.06, 0.0); }
  if (tt == 4.0) zoom *= 1.0 + q * 0.7;
  uv = (uv - 0.5) / zoom + 0.5 + off;

  // ---- mirror ----
  float mi = floor(uMirror + 0.5);
  if (mi == 1.0) { if (uv.x > 0.5) uv.x = 1.0 - uv.x; }
  else if (mi == 2.0) { if (uv.y > 0.5) uv.y = 1.0 - uv.y; }
  else if (mi == 3.0) { if (uv.x > 0.5) uv.x = 1.0 - uv.x; if (uv.y > 0.5) uv.y = 1.0 - uv.y; }

  // ---- pixelate ----
  if (pixAmt > 1.0) {
    vec2 g = uTexel * pixAmt;
    uv = (floor(uv / g) + 0.5) * g;
  }

  // ---- vhs wobble + glitch ----
  float chroma = uChroma;
  if (uVhs > 0.0) {
    uv.x += uVhs * 0.002 * sin(uv.y * 60.0 + t * 25.0);
    chroma += uVhs * 0.002;
  }
  if (glitchAmt > 0.0) {
    float slot = floor(t * 12.0);
    float band = floor(uv.y * 24.0);
    float r = hash(vec2(band, slot));
    if (r > 0.82) {
      uv.x += (hash(vec2(band, slot + 7.0)) - 0.5) * 0.1 * glitchAmt;
      chroma += 0.006 * glitchAmt;
    }
  }

  // ---- sample ----
  vec3 col;
  if (chroma > 0.0) {
    col = vec3(tex(uv + vec2(chroma, 0.0)).r, tex(uv).g, tex(uv - vec2(chroma, 0.0)).b);
  } else {
    col = tex(uv);
  }

  // ---- blur ----
  if (blurAmt > 0.0) {
    vec3 acc = vec3(0.0);
    for (int i = -2; i <= 2; i++) {
      for (int j = -2; j <= 2; j++) {
        acc += tex(uv + vec2(float(i), float(j)) * uTexel * blurAmt);
      }
    }
    col = acc / 25.0;
  }

  // ---- denoise (edge preserving) ----
  if (uDenoise > 0.0) {
    float k = 400.0 / (1.0 + 7.0 * uDenoise);
    vec3 sum = col;
    float ws = 1.0;
    for (int i = -1; i <= 1; i++) {
      for (int j = -1; j <= 1; j++) {
        if (i != 0 || j != 0) {
          vec3 s = tex(uv + vec2(float(i), float(j)) * uTexel);
          vec3 d = s - col;
          float w = exp(-dot(d, d) * k);
          sum += s * w;
          ws += w;
        }
      }
    }
    col = mix(col, sum / ws, clamp(uDenoise * 1.2, 0.0, 1.0));
  }

  // ---- sharpen (detail) ----
  if (uSharp > 0.0) {
    vec3 n = tex(uv + vec2(0.0, uTexel.y));
    vec3 s = tex(uv - vec2(0.0, uTexel.y));
    vec3 e = tex(uv + vec2(uTexel.x, 0.0));
    vec3 w = tex(uv - vec2(uTexel.x, 0.0));
    vec3 bl = (n + s + e + w) * 0.25;
    col += (col - bl) * uSharp * 2.5;
  }

  // ---- bloom / glow ----
  if (uBloom > 0.0) {
    vec3 b = vec3(0.0);
    for (int i = 0; i < 8; i++) {
      float a = float(i) * 0.7854;
      vec3 s = tex(uv + vec2(cos(a), sin(a)) * uTexel * 10.0);
      b += max(s - 0.55, 0.0);
    }
    col += b * 0.25 * uBloom;
  }

  // ---- color adjust ----
  col += uBright;
  col = (col - 0.5) * uContrast + 0.5;
  float l = dot(col, vec3(0.2126, 0.7152, 0.0722));
  col = mix(vec3(l), col, uSat);
  col.r += uWarm * 0.08;
  col.b -= uWarm * 0.08;
  col.g += uTint * 0.05;
  l = dot(col, vec3(0.2126, 0.7152, 0.0722));

  float cm = floor(uColorMode + 0.5);
  if (cm == 1.0) col = vec3(l);
  else if (cm == 2.0) col = vec3(l * 1.1, l * 0.85, l * 0.6);
  else if (cm == 3.0) col = vec3(1.0) - col;
  else if (cm == 4.0) col = mix(vec3(0.1, 0.0, 0.3), vec3(1.0, 0.6, 0.2), l);
  else if (cm == 5.0) col = mix(col, mix(vec3(0.0, 0.6, 0.8), vec3(1.0, 0.3, 0.7), l) * (0.4 + l), 0.5);
  else if (cm == 6.0) col = mix(col, vec3(l), 0.25) * vec3(1.05, 0.95, 0.8) + 0.04;
  else if (cm == 7.0) col = mix(col, col * mix(vec3(0.85, 1.0, 1.1), vec3(1.15, 1.0, 0.85), l), 0.8);

  // ---- vignette, grain, scanlines ----
  float d = distance(vTexSamplingCoord, vec2(0.5));
  col *= 1.0 - uVignette * smoothstep(0.3, 0.85, d);
  if (uGrain > 0.0) {
    vec2 pp = floor(vTexSamplingCoord / uTexel);
    col += (hash(pp * 0.0137 + fract(t * 7.0) * 13.0) - 0.5) * uGrain * 0.3;
  }
  if (uVhs > 0.0) {
    col *= 1.0 - uVhs * 0.18 * (0.5 + 0.5 * sin(vTexSamplingCoord.y / uTexel.y * 3.1416));
  }

  // ---- transition color part ----
  if (tt == 1.0 || tt == 4.0) col *= p;
  else if (tt == 2.0) col = mix(vec3(1.0), col, p);
  else if (tt == 3.0) col *= step(vTexSamplingCoord.x, p);
  else if (tt == 6.0) col += vec3(q * q);
  else if (tt == 8.0) col *= step(d, p * 0.75);
  else if (tt == 5.0 || tt == 7.0 || tt == 9.0) col *= mix(0.35, 1.0, p);

  gl_FragColor = vec4(clamp(col, 0.0, 1.0), 1.0);
}
"""
    }
}
