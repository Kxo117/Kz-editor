package com.kz.editor.ui

enum class Tool(val label: String, val glyph: String) {
    Edit("Edit", "✂"),
    Audio("Audio", "♪"),
    Text("Text", "T"),
    Effects("Effects", "✦"),
    Captions("Captions", "CC"),
    Filters("Filters", "◐"),
    Adjust("Adjust", "☰"),
    Enhance("Enhance", "HD")
}
