package com.kz.editor.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.kz.editor.EditorViewModel
import com.kz.editor.AspectOpt
import com.kz.editor.captions.Caption
import com.kz.editor.captions.CaptionStyle
import com.kz.editor.effects.EnhancerPreset
import com.kz.editor.effects.Motion
import com.kz.editor.effects.StyleEffect
import com.kz.editor.effects.Transition
import com.kz.editor.previewEffects
import kotlinx.coroutines.delay

private val TABS = listOf("Edit", "Looks", "Effects", "Motion", "Transitions", "Adjust", "Pro", "Captions", "Export")

@OptIn(ExperimentalMaterial3Api::class)
@UnstableApi
@Composable
fun EditorScreen(vm: EditorViewModel = viewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val player = remember { ExoPlayer.Builder(context).build() }
    DisposableEffect(Unit) { onDispose { player.release() } }

    var positionMs by remember { mutableLongStateOf(0L) }
    LaunchedEffect(player) {
        while (true) { positionMs = player.currentPosition; delay(100) }
    }

    LaunchedEffect(state.uri) {
        state.uri?.let {
            player.setMediaItem(MediaItem.fromUri(it))
            player.prepare()
        }
    }
    val previewFx = state.fxParams(state.durationMs / 1000f).toMap()
    LaunchedEffect(previewFx, state.rotation, state.flipH, state.uri) {
        if (state.uri != null) {
            delay(200)
            player.setVideoEffects(previewEffects(state, previewFx))
        }
    }
    LaunchedEffect(state.speed) { player.setPlaybackSpeed(state.speed) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri: Uri? ->
        uri?.let(vm::onVideoPicked)
    }
    var tab by remember { mutableIntStateOf(0) }
    var showCaptionDialog by remember { mutableStateOf(false) }
    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(state.message) {
        state.message?.let { snackbar.showSnackbar(it); vm.clearMessage() }
    }

    Scaffold(
        containerColor = Color.Black,
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text("kz editor", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Black),
                actions = {
                    TextButton(onClick = {
                        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
                    }) { Text("Open video") }
                }
            )
        }
    ) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (state.uri == null) {
                Box(Modifier.fillMaxWidth().height(300.dp), contentAlignment = Alignment.Center) {
                    Text("Tap “Open video” to start", color = Color.Gray)
                }
                return@Column
            }

            Box(Modifier.fillMaxWidth().height(340.dp).background(Color.Black)) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { PlayerView(it).apply { this.player = player; useController = true } }
                )
                val cap = state.captions.firstOrNull { positionMs >= it.startMs && positionMs < it.endMs }
                if (cap != null) {
                    val lines = cap.text.split("\n")
                    Column(
                        Modifier.align(Alignment.BottomCenter).padding(bottom = 72.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(lines.first(), color = Color(state.captionStyle.c1), fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        lines.drop(1).forEach {
                            Text(it, color = Color(state.captionStyle.c2), fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            if (state.exporting) {
                LinearProgressIndicator(progress = { state.progress }, modifier = Modifier.fillMaxWidth())
                Text("Exporting… ${(state.progress * 100).toInt()}%", color = Color.White)
            }

            ScrollableTabRow(selectedTabIndex = tab, containerColor = Color.Black, edgePadding = 0.dp) {
                TABS.forEachIndexed { i, t ->
                    Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) })
                }
            }

            when (tab) {
                0 -> { // Edit
                    Title("Trim  ${fmt(state.trimStartMs)} – ${fmt(state.trimEndMs)}")
                    RangeSlider(
                        value = state.trimStartMs.toFloat()..state.trimEndMs.toFloat(),
                        onValueChange = { r ->
                            vm.set { it.copy(trimStartMs = r.start.toLong(), trimEndMs = r.endInclusive.toLong()) }
                        },
                        valueRange = 0f..state.durationMs.toFloat().coerceAtLeast(1f)
                    )
                    Title("Speed")
                    ChipRow(listOf(0.25f, 0.5f, 0.75f, 1f, 1.5f, 2f, 3f), state.speed, { "${it}x" }) { v ->
                        vm.set { it.copy(speed = v) }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Button(onClick = { vm.set { it.copy(rotation = (it.rotation + 90) % 360) } }) { Text("Rotate 90°") }
                        FilterChip(selected = state.flipH, onClick = { vm.set { it.copy(flipH = !it.flipH) } }, label = { Text("Flip") })
                        FilterChip(selected = state.mute, onClick = { vm.set { it.copy(mute = !it.mute) } }, label = { Text("Mute") })
                    }
                }
                1 -> { // Looks
                    Title("Visual Enhancer / Looks")
                    ChipRow(EnhancerPreset.values().toList(), state.look, { it.label }) { v -> vm.set { it.copy(look = v) } }
                }
                2 -> { // Effects
                    Title("Effects")
                    ChipRow(StyleEffect.values().toList(), state.style, { it.label }) { v -> vm.set { it.copy(style = v) } }
                }
                3 -> { // Motion
                    Title("Motion")
                    ChipRow(Motion.values().toList(), state.motion, { it.label }) { v -> vm.set { it.copy(motion = v) } }
                }
                4 -> { // Transitions
                    Title("Intro transition")
                    ChipRow(Transition.values().toList(), state.transIn, { it.label }) { v -> vm.set { it.copy(transIn = v) } }
                    Title("Outro transition")
                    ChipRow(Transition.values().toList(), state.transOut, { it.label }) { v -> vm.set { it.copy(transOut = v) } }
                    Text("Preview shows transitions at the start/end of the full video; export uses your trim.", color = Color.Gray, fontSize = 12.sp)
                }
                5 -> { // Adjust
                    LabeledSlider("Brightness", state.bright, -0.3f..0.3f) { v -> vm.set { it.copy(bright = v) } }
                    LabeledSlider("Contrast", state.contrast, 0.6f..1.6f) { v -> vm.set { it.copy(contrast = v) } }
                    LabeledSlider("Saturation", state.sat, 0f..2f) { v -> vm.set { it.copy(sat = v) } }
                    LabeledSlider("Warmth", state.warm, -2f..2f) { v -> vm.set { it.copy(warm = v) } }
                    LabeledSlider("Vignette", state.vignette, 0f..1f) { v -> vm.set { it.copy(vignette = v) } }
                    LabeledSlider("Grain", state.grain, 0f..1f) { v -> vm.set { it.copy(grain = v) } }
                    TextButton(onClick = {
                        vm.set { it.copy(bright = 0f, contrast = 1f, sat = 1f, warm = 0f, vignette = 0f, grain = 0f) }
                    }) { Text("Reset") }
                }
                6 -> { // Pro
                    Title("Pro Enhance (GPU)")
                    Button(onClick = {
                        vm.set { it.copy(denoise = 0.3f, sharp = 0.45f, contrast = 1.06f, sat = 1.1f) }
                    }) { Text("Auto Enhance") }
                    LabeledSlider("Denoise", state.denoise, 0f..1f) { v -> vm.set { it.copy(denoise = v) } }
                    LabeledSlider("Detail / Sharpness", state.sharp, 0f..1.5f) { v -> vm.set { it.copy(sharp = v) } }
                    Text("For upscaling choose 1440p / 4K in the Export tab; denoise + detail are applied after scaling.", color = Color.Gray, fontSize = 12.sp)
                }
                7 -> { // Captions
                    Title("Caption style")
                    ChipRow(CaptionStyle.values().toList(), state.captionStyle, { it.label }) { v ->
                        vm.set { it.copy(captionStyle = v) }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Title("Captions (CC)", Modifier.weight(1f))
                        Button(onClick = { showCaptionDialog = true }) { Text("+ Add") }
                    }
                    state.captions.sortedBy { it.startMs }.forEach { c ->
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text("${fmt(c.startMs)}  ${c.text.replace("\n", " / ")}", Modifier.weight(1f), color = Color.White)
                            TextButton(onClick = { vm.removeCaption(c) }) { Text("Delete") }
                        }
                    }
                }
                8 -> { // Export
                    Title("Aspect ratio")
                    ChipRow(AspectOpt.values().toList(), state.aspect, { it.label }) { v -> vm.set { it.copy(aspect = v) } }
                    Title("Quality")
                    ChipRow(
                        listOf(0, 720, 1080, 1440, 2160), state.quality,
                        { when (it) { 0 -> "Source"; 720 -> "HD 720p"; 1080 -> "Full HD"; 1440 -> "2K"; else -> "4K" } }
                    ) { v -> vm.set { it.copy(quality = v) } }
                    val (ow, oh) = state.outSize()
                    Text("Output: ${ow} x ${oh}", color = Color.Gray)
                    Button(onClick = vm::export, enabled = !state.exporting, modifier = Modifier.fillMaxWidth()) {
                        Text(if (state.exporting) "Exporting… ${(state.progress * 100).toInt()}%" else "Export")
                    }
                }
            }
        }
    }

    if (showCaptionDialog) {
        CaptionDialog(
            startDefaultMs = positionMs,
            onDismiss = { showCaptionDialog = false },
            onAdd = { vm.addCaption(it); showCaptionDialog = false }
        )
    }
}

@Composable
private fun Title(text: String, modifier: Modifier = Modifier) =
    Text(text, modifier, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)

@Composable
private fun <T> ChipRow(items: List<T>, selected: T, label: (T) -> String, onSelect: (T) -> Unit) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(items) { item ->
            FilterChip(selected = item == selected, onClick = { onSelect(item) }, label = { Text(label(item)) })
        }
    }
}

@Composable
private fun LabeledSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Column {
        Text("$label  ${"%.2f".format(value)}", color = Color.White, fontSize = 13.sp)
        Slider(value = value, onValueChange = onChange, valueRange = range)
    }
}

@Composable
private fun CaptionDialog(startDefaultMs: Long, onDismiss: () -> Unit, onAdd: (Caption) -> Unit) {
    var text by remember { mutableStateOf("") }
    var start by remember { mutableStateOf("%.1f".format(startDefaultMs / 1000.0)) }
    var end by remember { mutableStateOf("%.1f".format(startDefaultMs / 1000.0 + 2.5)) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New caption") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(text, { text = it }, label = { Text("Text (line 1 white, next lines colored)") })
                OutlinedTextField(start, { start = it }, label = { Text("Start (sec)") })
                OutlinedTextField(end, { end = it }, label = { Text("End (sec)") })
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val s = start.toDoubleOrNull()
                val e = end.toDoubleOrNull()
                if (text.isNotBlank() && s != null && e != null && e > s)
                    onAdd(Caption((s * 1000).toLong(), (e * 1000).toLong(), text))
            }) { Text("Add") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

private fun fmt(ms: Long): String = "%d:%02d.%d".format(ms / 60000, ms / 1000 % 60, ms % 1000 / 100)
