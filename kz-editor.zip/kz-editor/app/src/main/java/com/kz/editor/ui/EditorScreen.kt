package com.kz.editor.ui

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.kz.editor.EditorViewModel
import com.kz.editor.captions.Caption
import com.kz.editor.effects.EnhancerPreset
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@UnstableApi
@Composable
fun EditorScreen(vm: EditorViewModel = viewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val player = remember { ExoPlayer.Builder(context).build() }
    DisposableEffect(Unit) { onDispose { player.release() } }

    var positionMs by remember { mutableLongStateOf(0L) }
    LaunchedEffect(player) {
        while (true) { positionMs = player.currentPosition; delay(100) }
    }

    LaunchedEffect(state.uri) {
        state.uri?.let {
            player.setVideoEffects(state.preset.effects())
            player.setMediaItem(MediaItem.fromUri(it))
            player.prepare()
        }
    }
    LaunchedEffect(state.preset) { player.setVideoEffects(state.preset.effects()) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri: Uri? ->
        uri?.let(vm::onVideoPicked)
    }
    var showCaptionDialog by remember { mutableStateOf(false) }
    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(state.message) {
        state.message?.let { snackbar.showSnackbar(it); vm.clearMessage() }
    }

    Scaffold(
        containerColor = Color.Black,
        snackbarHost = { SnackbarHost(snackbar) },
        topBar = {
            TopAppBar(
                title = { Text("kz editor", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Black),
                actions = { TextButton(onClick = {
                    picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly))
                }) { Text("Open video") } }
            )
        }
    ) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            if (state.uri == null) {
                Box(Modifier.fillMaxWidth().height(300.dp), contentAlignment = Alignment.Center) {
                    Text("Tap “Open video” to start", color = Color.Gray)
                }
                return@Column
            }

            Box(Modifier.fillMaxWidth().height(360.dp).background(Color.Black)) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { PlayerView(it).apply { this.player = player; useController = true } }
                )
                val cap = state.captions.firstOrNull { positionMs >= it.startMs && positionMs < it.endMs }
                if (cap != null) {
                    val lines = cap.text.split("\n")
                    Column(
                        Modifier.align(Alignment.BottomCenter).padding(bottom = 72.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(lines.first(), color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        lines.drop(1).forEach {
                            Text(it, color = Color(0xFF2D5BFF), fontSize = 24.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            SectionTitle("Visual Enhancer")
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(EnhancerPreset.values().toList()) { p ->
                    FilterChip(selected = state.preset == p, onClick = { vm.setPreset(p) }, label = { Text(p.label) })
                }
            }

            SectionTitle("Trim  ${fmt(state.trimStartMs)} – ${fmt(state.trimEndMs)}")
            RangeSlider(
                value = state.trimStartMs.toFloat()..state.trimEndMs.toFloat(),
                onValueChange = { vm.setTrim(it.start.toLong(), it.endInclusive.toLong()) },
                valueRange = 0f..state.durationMs.toFloat().coerceAtLeast(1f)
            )

            Row(verticalAlignment = Alignment.CenterVertically) {
                SectionTitle("Captions (CC)", Modifier.weight(1f))
                Button(onClick = { showCaptionDialog = true }) { Text("+ Add") }
            }
            state.captions.sortedBy { it.startMs }.forEach { c ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("${fmt(c.startMs)}  ${c.text.replace("\n", " / ")}", Modifier.weight(1f), color = Color.White)
                    TextButton(onClick = { vm.removeCaption(c) }) { Text("Delete") }
                }
            }

            SectionTitle("Export quality")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(720 to "HD 720p", 1080 to "Full HD 1080p", 2160 to "4K").forEach { (h, label) ->
                    FilterChip(selected = state.exportHeight == h, onClick = { vm.setExportHeight(h) }, label = { Text(label) })
                }
            }
            if (state.exporting) {
                LinearProgressIndicator(progress = { state.progress }, modifier = Modifier.fillMaxWidth())
            }
            Button(onClick = vm::export, enabled = !state.exporting, modifier = Modifier.fillMaxWidth()) {
                Text(if (state.exporting) "Exporting… ${(state.progress * 100).toInt()}%" else "Export")
            }
        }
    }

    if (showCaptionDialog) {
        CaptionDialog(
            startDefaultMs = positionMs,
            onDismiss = { showCaptionDialog = false },
            onAdd = { vm.addCaption(it); showCaptionDialog = false }
        )
    }
}

@Composable
private fun SectionTitle(text: String, modifier: Modifier = Modifier) =
    Text(text, modifier, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)

@Composable
private fun CaptionDialog(startDefaultMs: Long, onDismiss: () -> Unit, onAdd: (Caption) -> Unit) {
    var text by remember { mutableStateOf("") }
    var start by remember { mutableStateOf("%.1f".format(startDefaultMs / 1000.0)) }
    var end by remember { mutableStateOf("%.1f".format(startDefaultMs / 1000.0 + 2.5)) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New caption") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(text, { text = it }, label = { Text("Text (line 1 white, next lines blue)") })
                OutlinedTextField(start, { start = it }, label = { Text("Start (sec)") })
                OutlinedTextField(end, { end = it }, label = { Text("End (sec)") })
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val s = start.toDoubleOrNull(); val e = end.toDoubleOrNull()
                if (text.isNotBlank() && s != null && e != null && e > s)
                    onAdd(Caption((s * 1000).toLong(), (e * 1000).toLong(), text))
            }) { Text("Add") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

private fun fmt(ms: Long): String = "%d:%02d.%d".format(ms / 60000, ms / 1000 % 60, ms % 1000 / 100)
