@file:OptIn(androidx.media3.common.util.UnstableApi::class)

package com.kz.editor.ui

import android.graphics.Bitmap
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import com.kz.editor.AspectOpt
import com.kz.editor.EditorState
import com.kz.editor.EditorViewModel
import com.kz.editor.captions.Caption
import com.kz.editor.captions.CaptionStyle
import com.kz.editor.effects.EnhancerPreset
import com.kz.editor.effects.Motion
import com.kz.editor.effects.StyleEffect
import com.kz.editor.effects.Transition
import com.kz.editor.previewEffects
import kotlinx.coroutines.delay

private val BG = Color(0xFF121212)
private val PANEL = Color(0xFF1C1C1C)
private val CYAN = Color(0xFF00D4E6)

private fun qualityLabel(q: Int) = when (q) {
    0 -> "Source"
    720 -> "720P"
    1080 -> "1080P"
    1440 -> "2K"
    else -> "4K"
}

private fun fmtTime(ms: Long) = "%02d:%02d".format(ms / 60000, ms / 1000 % 60)

@UnstableApi
@Composable
fun EditorScreen(startTool: Tool?, onClose: () -> Unit, vm: EditorViewModel = viewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    val thumbs by vm.thumbs.collectAsStateWithLifecycle()
    val context = LocalContext.current
    val player = remember { ExoPlayer.Builder(context).build() }
    DisposableEffect(Unit) { onDispose { player.release() } }

    var playing by remember { mutableStateOf(false) }
    DisposableEffect(player) {
        val l = object : Player.Listener {
            override fun onIsPlayingChanged(isPlaying: Boolean) { playing = isPlaying }
        }
        player.addListener(l)
        onDispose { player.removeListener(l) }
    }

    var positionMs by remember { mutableLongStateOf(0L) }
    LaunchedEffect(player) {
        while (true) { positionMs = player.currentPosition; delay(100) }
    }

    LaunchedEffect(state.uri) {
        state.uri?.let {
            player.setMediaItem(MediaItem.fromUri(it))
            player.prepare()
        }
    }
    val previewFx = state.fxParams(state.durationMs / 1000f).toMap()
    LaunchedEffect(previewFx, state.rotation, state.flipH, state.uri) {
        if (state.uri != null) {
            delay(200)
            player.setVideoEffects(previewEffects(state, previewFx))
        }
    }
    LaunchedEffect(state.speed) { player.setPlaybackSpeed(state.speed) }
    LaunchedEffect(state.mute) { player.volume = if (state.mute) 0f else 1f }

    var tool by remember { mutableStateOf(startTool) }
    var showCaptionDialog by remember { mutableStateOf(false) }
    var qualityMenu by remember { mutableStateOf(false) }
    val snackbar = remember { SnackbarHostState() }
    LaunchedEffect(state.message) {
        state.message?.let { snackbar.showSnackbar(it); vm.clearMessage() }
    }

    Scaffold(
        containerColor = BG,
        contentColor = Color.White,
        snackbarHost = { SnackbarHost(snackbar) }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
            // ---- top bar ----
            Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                TextButton(onClick = onClose) { Text("✕", color = Color.White, fontSize = 20.sp) }
                Spacer(Modifier.weight(1f))
                Box {
                    OutlinedButton(onClick = { qualityMenu = true }) {
                        Text(qualityLabel(state.quality) + " ▾", color = Color.White)
                    }
                    DropdownMenu(expanded = qualityMenu, onDismissRequest = { qualityMenu = false }) {
                        listOf(0, 720, 1080, 1440, 2160).forEach { q ->
                            DropdownMenuItem(
                                text = { Text(qualityLabel(q)) },
                                onClick = { vm.set { it.copy(quality = q) }; qualityMenu = false }
                            )
                        }
                    }
                }
                Spacer(Modifier.width(8.dp))
                Button(
                    onClick = vm::export,
                    enabled = !state.exporting,
                    colors = ButtonDefaults.buttonColors(containerColor = CYAN, contentColor = Color.Black)
                ) { Text(if (state.exporting) "${(state.progress * 100).toInt()}%" else "Export", fontWeight = FontWeight.Bold) }
            }

            // ---- preview ----
            Box(Modifier.weight(1f).fillMaxWidth().background(Color.Black)) {
                AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { PlayerView(it).apply { this.player = player; useController = false } }
                )
                val cap = state.captions.firstOrNull { positionMs >= it.startMs && positionMs < it.endMs }
                if (cap != null) {
                    val lines = cap.text.split("\n")
                    Column(
                        Modifier.align(Alignment.BottomCenter).padding(bottom = 24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(lines.first(), color = Color(state.captionStyle.c1), fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        lines.drop(1).forEach {
                            Text(it, color = Color(state.captionStyle.c2), fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
                if (state.exporting) {
                    LinearProgressIndicator(progress = { state.progress }, modifier = Modifier.fillMaxWidth().align(Alignment.TopCenter))
                }
            }

            // ---- controls ----
            Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    "${fmtTime(positionMs)} / ${fmtTime(state.durationMs)}",
                    color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(1f)
                )
                TextButton(onClick = { if (playing) player.pause() else player.play() }) {
                    Text(if (playing) "⏸" else "▶", color = Color.White, fontSize = 26.sp)
                }
                Row(Modifier.weight(1f), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = vm::undo) { Text("↶", color = Color.White, fontSize = 22.sp) }
                    TextButton(onClick = vm::redo) { Text("↷", color = Color.White, fontSize = 22.sp) }
                }
            }

            // ---- timeline ----
            Timeline(
                state = state,
                thumbs = thumbs,
                positionMs = positionMs,
                onSeek = { ms -> player.seekTo(ms); positionMs = ms },
                onAddText = { showCaptionDialog = true },
                onRemoveCaption = vm::removeCaption
            )

            // ---- tool panel ----
            tool?.let { ToolPanel(it, state, vm) { showCaptionDialog = true } }

            // ---- bottom toolbar ----
            LazyRow(
                Modifier.fillMaxWidth().background(BG).padding(vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                items(Tool.values().toList()) { t ->
                    Column(
                        Modifier.width(76.dp).clickable { tool = if (tool == t) null else t }.padding(vertical = 4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        val c = if (tool == t) CYAN else Color.White
                        Text(t.glyph, color = c, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text(t.label, color = c, fontSize = 12.sp)
                    }
                }
            }
        }
    }

    if (showCaptionDialog) {
        CaptionDialog(
            startDefaultMs = positionMs,
            onDismiss = { showCaptionDialog = false },
            onAdd = { vm.addCaption(it); showCaptionDialog = false }
        )
    }
}

@Composable
private fun Timeline(
    state: EditorState,
    thumbs: List<Bitmap>,
    positionMs: Long,
    onSeek: (Long) -> Unit,
    onAddText: () -> Unit,
    onRemoveCaption: (Caption) -> Unit
) {
    val dur = state.durationMs.coerceAtLeast(1L)
    Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Box(
            Modifier.fillMaxWidth().height(56.dp).clip(RoundedCornerShape(6.dp)).background(Color(0xFF2A2A2A))
                .pointerInput(dur) {
                    detectTapGestures { off -> onSeek((off.x / size.width * dur).toLong().coerceIn(0L, dur)) }
                }
                .pointerInput(dur) {
                    detectHorizontalDragGestures { change, _ ->
                        change.consume()
                        onSeek((change.position.x / size.width * dur).toLong().coerceIn(0L, dur))
                    }
                }
        ) {
            Row(Modifier.fillMaxSize()) {
                thumbs.forEach {
                    Image(it.asImageBitmap(), null, Modifier.weight(1f).fillMaxHeight(), contentScale = ContentScale.Crop)
                }
            }
            val fs = (state.trimStartMs.toFloat() / dur).coerceIn(0f, 1f)
            val fe = (state.trimEndMs.toFloat() / dur).coerceIn(0f, 1f)
            Box(Modifier.align(Alignment.CenterStart).fillMaxHeight().fillMaxWidth(fs).background(Color(0xAA000000)))
            Box(Modifier.align(Alignment.CenterEnd).fillMaxHeight().fillMaxWidth(1f - fe).background(Color(0xAA000000)))
            Box(Modifier.fillMaxHeight().fillMaxWidth((positionMs.toFloat() / dur).coerceIn(0f, 1f))) {
                Box(Modifier.align(Alignment.CenterEnd).width(2.dp).fillMaxHeight().background(Color.White))
            }
        }
        Row(
            Modifier.fillMaxWidth().height(34.dp).clip(RoundedCornerShape(6.dp)).background(Color(0xFF2A2A2A))
                .clickable(onClick = onAddText).padding(horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) { Text("+ Add text", color = Color.Gray, fontSize = 13.sp) }
        if (state.captions.isNotEmpty()) {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                items(state.captions.sortedBy { it.startMs }) { c ->
                    AssistChip(onClick = { onRemoveCaption(c) }, label = { Text("✕ " + c.text.replace("\n", " ").take(14)) })
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ToolPanel(tool: Tool, state: EditorState, vm: EditorViewModel, onAddText: () -> Unit) {
    Column(
        Modifier.fillMaxWidth().heightIn(max = 240.dp).background(PANEL)
            .verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        when (tool) {
            Tool.Edit -> {
                Title("Trim  ${fmtTime(state.trimStartMs)} – ${fmtTime(state.trimEndMs)}")
                RangeSlider(
                    value = state.trimStartMs.toFloat()..state.trimEndMs.toFloat(),
                    onValueChange = { r -> vm.set { it.copy(trimStartMs = r.start.toLong(), trimEndMs = r.endInclusive.toLong()) } },
                    valueRange = 0f..state.durationMs.toFloat().coerceAtLeast(1f)
                )
                Title("Speed")
                ChipRow(listOf(0.25f, 0.5f, 0.75f, 1f, 1.5f, 2f, 3f), state.speed, { "${it}x" }) { v -> vm.set { it.copy(speed = v) } }
                Title("Ratio")
                ChipRow(AspectOpt.values().toList(), state.aspect, { it.label }) { v -> vm.set { it.copy(aspect = v) } }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Button(onClick = { vm.set { it.copy(rotation = (it.rotation + 90) % 360) } }) { Text("Rotate 90°") }
                    FilterChip(selected = state.flipH, onClick = { vm.set { it.copy(flipH = !it.flipH) } }, label = { Text("Flip") })
                }
                val (ow, oh) = state.outSize()
                Text("Output: $ow x $oh", color = Color.Gray, fontSize = 12.sp)
            }
            Tool.Audio -> {
                FilterChip(selected = state.mute, onClick = { vm.set { it.copy(mute = !it.mute) } }, label = { Text("Mute clip") })
                Text("Music, voice-over and audio mixing: coming in the next version.", color = Color.Gray, fontSize = 12.sp)
            }
            Tool.Text -> {
                Button(onClick = onAddText) { Text("+ Add text") }
                Title("Text style")
                ChipRow(CaptionStyle.values().toList(), state.captionStyle, { it.label }) { v -> vm.set { it.copy(captionStyle = v) } }
                Text("Line 1 is white, next lines use the accent color. Amharic works.", color = Color.Gray, fontSize = 12.sp)
            }
            Tool.Effects -> {
                Title("Effects")
                ChipRow(StyleEffect.values().toList(), state.style, { it.label }) { v -> vm.set { it.copy(style = v) } }
                Title("Motion")
                ChipRow(Motion.values().toList(), state.motion, { it.label }) { v -> vm.set { it.copy(motion = v) } }
                Title("Intro transition")
                ChipRow(Transition.values().toList(), state.transIn, { it.label }) { v -> vm.set { it.copy(transIn = v) } }
                Title("Outro transition")
                ChipRow(Transition.values().toList(), state.transOut, { it.label }) { v -> vm.set { it.copy(transOut = v) } }
            }
            Tool.Captions -> {
                Title("Caption style")
                ChipRow(CaptionStyle.values().toList(), state.captionStyle, { it.label }) { v -> vm.set { it.copy(captionStyle = v) } }
                Button(onClick = onAddText) { Text("+ Add caption") }
                Text("Auto captions (Whisper): coming in the next version. Export also saves an .srt file.", color = Color.Gray, fontSize = 12.sp)
            }
            Tool.Filters -> {
                Title("Visual Enhancer / Looks")
                ChipRow(EnhancerPreset.values().toList(), state.look, { it.label }) { v -> vm.set { it.copy(look = v) } }
            }
            Tool.Adjust -> {
                LabeledSlider("Brightness", state.bright, -0.3f..0.3f) { v -> vm.set { it.copy(bright = v) } }
                LabeledSlider("Contrast", state.contrast, 0.6f..1.6f) { v -> vm.set { it.copy(contrast = v) } }
                LabeledSlider("Saturation", state.sat, 0f..2f) { v -> vm.set { it.copy(sat = v) } }
                LabeledSlider("Warmth", state.warm, -2f..2f) { v -> vm.set { it.copy(warm = v) } }
                LabeledSlider("Vignette", state.vignette, 0f..1f) { v -> vm.set { it.copy(vignette = v) } }
                LabeledSlider("Grain", state.grain, 0f..1f) { v -> vm.set { it.copy(grain = v) } }
                TextButton(onClick = {
                    vm.set { it.copy(bright = 0f, contrast = 1f, sat = 1f, warm = 0f, vignette = 0f, grain = 0f) }
                }) { Text("Reset") }
            }
            Tool.Enhance -> {
                Button(onClick = {
                    vm.set { it.copy(denoise = 0.3f, sharp = 0.45f, contrast = 1.06f, sat = 1.1f) }
                }) { Text("Auto Enhance") }
                LabeledSlider("Denoise", state.denoise, 0f..1f) { v -> vm.set { it.copy(denoise = v) } }
                LabeledSlider("Detail / Sharpness", state.sharp, 0f..1.5f) { v -> vm.set { it.copy(sharp = v) } }
                Text("For upscaling pick 2K / 4K from the top-right menu. GPU filters, not AI.", color = Color.Gray, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun Title(text: String, modifier: Modifier = Modifier) =
    Text(text, modifier, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp)

@Composable
private fun <T> ChipRow(items: List<T>, selected: T, label: (T) -> String, onSelect: (T) -> Unit) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        items(items) { item ->
            FilterChip(selected = item == selected, onClick = { onSelect(item) }, label = { Text(label(item)) })
        }
    }
}

@Composable
private fun LabeledSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, onChange: (Float) -> Unit) {
    Column {
        Text("$label  ${"%.2f".format(value)}", color = Color.White, fontSize = 13.sp)
        Slider(value = value, onValueChange = onChange, valueRange = range)
    }
}

@Composable
private fun CaptionDialog(startDefaultMs: Long, onDismiss: () -> Unit, onAdd: (Caption) -> Unit) {
    var text by remember { mutableStateOf("") }
    var start by remember { mutableStateOf("%.1f".format(startDefaultMs / 1000.0)) }
    var end by remember { mutableStateOf("%.1f".format(startDefaultMs / 1000.0 + 2.5)) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("New text") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(text, { text = it }, label = { Text("Text (line 1 white, next lines colored)") })
                OutlinedTextField(start, { start = it }, label = { Text("Start (sec)") })
                OutlinedTextField(end, { end = it }, label = { Text("End (sec)") })
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val s = start.toDoubleOrNull()
                val e = end.toDoubleOrNull()
                if (text.isNotBlank() && s != null && e != null && e > s)
                    onAdd(Caption((s * 1000).toLong(), (e * 1000).toLong(), text))
            }) { Text("Add") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
