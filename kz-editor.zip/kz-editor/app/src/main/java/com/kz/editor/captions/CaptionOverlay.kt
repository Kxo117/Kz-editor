package com.kz.editor.captions

import android.graphics.Typeface
import android.text.SpannableString
import android.text.Spanned
import android.text.style.AbsoluteSizeSpan
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.OverlaySettings
import androidx.media3.effect.TextOverlay

/** Burns captions into the exported video. Times are relative to the output clip. */
@UnstableApi
class CaptionOverlay(
    private val captions: List<Caption>,
    private val textSizePx: Int,
    private val color1: Int,
    private val color2: Int
) : TextOverlay() {

    override fun getText(presentationTimeUs: Long): SpannableString {
        val ms = presentationTimeUs / 1000
        val c = captions.firstOrNull { ms >= it.startMs && ms < it.endMs }
            ?: return SpannableString(" ")
        val s = SpannableString(c.text)
        s.setSpan(AbsoluteSizeSpan(textSizePx, false), 0, s.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        s.setSpan(StyleSpan(Typeface.BOLD), 0, s.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        val nl = c.text.indexOf('\n')
        if (nl < 0) {
            s.setSpan(ForegroundColorSpan(color1), 0, s.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        } else {
            s.setSpan(ForegroundColorSpan(color1), 0, nl, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            s.setSpan(ForegroundColorSpan(color2), nl + 1, s.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        return s
    }

    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings =
        OverlaySettings.Builder()
            .setBackgroundFrameAnchor(0f, -0.45f)
            .build()
}
