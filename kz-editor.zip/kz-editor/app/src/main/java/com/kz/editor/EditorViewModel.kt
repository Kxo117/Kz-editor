package com.kz.editor

import android.app.Application
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.Presentation
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import com.google.common.collect.ImmutableList
import com.kz.editor.captions.Caption
import com.kz.editor.captions.CaptionOverlay
import com.kz.editor.captions.SrtWriter
import com.kz.editor.effects.EnhancerPreset
import com.kz.editor.export.MediaSaver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import java.io.File

@UnstableApi
data class EditorState(
    val uri: Uri? = null,
    val durationMs: Long = 0,
    val preset: EnhancerPreset = EnhancerPreset.Original,
    val trimStartMs: Long = 0,
    val trimEndMs: Long = 0,
    val captions: List<Caption> = emptyList(),
    val exportHeight: Int = 1080,
    val exporting: Boolean = false,
    val progress: Float = 0f,
    val message: String? = null
)

@UnstableApi
class EditorViewModel(app: Application) : AndroidViewModel(app) {
    private val _state = MutableStateFlow(EditorState())
    val state: StateFlow<EditorState> = _state

    fun onVideoPicked(uri: Uri) {
        val retriever = MediaMetadataRetriever()
        val duration = try {
            retriever.setDataSource(getApplication(), uri)
            retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
        } finally {
            retriever.release()
        }
        _state.value = EditorState(uri = uri, durationMs = duration, trimEndMs = duration)
    }

    fun setPreset(p: EnhancerPreset) = _state.update { it.copy(preset = p) }
    fun setTrim(start: Long, end: Long) = _state.update { it.copy(trimStartMs = start, trimEndMs = end) }
    fun setExportHeight(h: Int) = _state.update { it.copy(exportHeight = h) }
    fun addCaption(c: Caption) = _state.update { it.copy(captions = it.captions + c) }
    fun removeCaption(c: Caption) = _state.update { it.copy(captions = it.captions - c) }
    fun clearMessage() = _state.update { it.copy(message = null) }

    fun export() {
        val s = _state.value
        val uri = s.uri ?: return
        if (s.exporting) return
        val app = getApplication<Application>()
        val out = File(app.cacheDir, "kz_${System.currentTimeMillis()}.mp4")

        val clipping = MediaItem.ClippingConfiguration.Builder()
            .setStartPositionMs(s.trimStartMs)
            .setEndPositionMs(s.trimEndMs)
            .build()
        val mediaItem = MediaItem.Builder().setUri(uri).setClippingConfiguration(clipping).build()

        val shifted = s.captions.map { it.copy(startMs = it.startMs - s.trimStartMs, endMs = it.endMs - s.trimStartMs) }
        val effects = mutableListOf<Effect>()
        effects += Presentation.createForHeight(s.exportHeight)
        effects += s.preset.effects()
        if (shifted.isNotEmpty()) {
            effects += OverlayEffect(ImmutableList.of(CaptionOverlay(shifted, textSizePx = s.exportHeight / 17)))
        }
        val edited = EditedMediaItem.Builder(mediaItem)
            .setEffects(Effects(emptyList(), effects))
            .build()

        val bitrate = when {
            s.exportHeight >= 2160 -> 45_000_000
            s.exportHeight >= 1080 -> 16_000_000
            else -> 8_000_000
        }
        val encoderFactory = DefaultEncoderFactory.Builder(app)
            .setRequestedVideoEncoderSettings(VideoEncoderSettings.Builder().setBitrate(bitrate).build())
            .build()

        val transformer = Transformer.Builder(app)
            .setEncoderFactory(encoderFactory)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    viewModelScope.launch {
                        withContext(Dispatchers.IO) {
                            MediaSaver.saveVideo(app, out)
                            if (shifted.isNotEmpty()) MediaSaver.saveSrt(app, SrtWriter.write(shifted))
                            out.delete()
                        }
                        _state.update { it.copy(exporting = false, progress = 1f, message = "Saved: Movies/KZ Editor") }
                    }
                }

                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                    _state.update { it.copy(exporting = false, message = "Export failed: ${exportException.errorCodeName}") }
                }
            })
            .build()

        _state.update { it.copy(exporting = true, progress = 0f, message = null) }
        transformer.start(edited, out.absolutePath)

        viewModelScope.launch {
            val holder = ProgressHolder()
            while (_state.value.exporting) {
                if (transformer.getProgress(holder) != Transformer.PROGRESS_STATE_NOT_STARTED) {
                    _state.update { it.copy(progress = holder.progress / 100f) }
                }
                delay(300)
            }
        }
    }
}
