package com.kz.editor

import android.app.Application
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.SonicAudioProcessor
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.Presentation
import androidx.media3.effect.ScaleAndRotateTransformation
import androidx.media3.effect.SpeedChangeEffect
import androidx.media3.transformer.Composition
import androidx.media3.transformer.DefaultEncoderFactory
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.VideoEncoderSettings
import com.google.common.collect.ImmutableList
import com.kz.editor.captions.Caption
import com.kz.editor.captions.CaptionOverlay
import com.kz.editor.captions.CaptionStyle
import com.kz.editor.captions.SrtWriter
import com.kz.editor.effects.EnhancerPreset
import com.kz.editor.effects.FxParams
import com.kz.editor.effects.Motion
import com.kz.editor.effects.StyleEffect
import com.kz.editor.effects.Transition
import com.kz.editor.effects.UberEffect
import com.kz.editor.export.MediaSaver
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.min
import kotlin.math.roundToInt

enum class AspectOpt(val label: String, val ratio: Float) {
    Original("Original", 0f),
    R9x16("9:16", 9f / 16f),
    R16x9("16:9", 16f / 9f),
    R1x1("1:1", 1f),
    R4x5("4:5", 0.8f)
}

@UnstableApi
data class EditorState(
    val uri: Uri? = null,
    val durationMs: Long = 0,
    val srcW: Int = 1920,
    val srcH: Int = 1080,
    val look: EnhancerPreset = EnhancerPreset.Original,
    val style: StyleEffect = StyleEffect.None,
    val motion: Motion = Motion.None,
    val transIn: Transition = Transition.None,
    val transOut: Transition = Transition.None,
    val bright: Float = 0f,
    val contrast: Float = 1f,
    val sat: Float = 1f,
    val warm: Float = 0f,
    val vignette: Float = 0f,
    val grain: Float = 0f,
    val sharp: Float = 0f,
    val denoise: Float = 0f,
    val speed: Float = 1f,
    val rotation: Int = 0,
    val flipH: Boolean = false,
    val mute: Boolean = false,
    val aspect: AspectOpt = AspectOpt.Original,
    val quality: Int = 0,
    val trimStartMs: Long = 0,
    val trimEndMs: Long = 0,
    val captions: List<Caption> = emptyList(),
    val captionStyle: CaptionStyle = CaptionStyle.Classic,
    val exporting: Boolean = false,
    val progress: Float = 0f,
    val message: String? = null
) {
    fun fxParams(durSec: Float): FxParams {
        val p = FxParams()
        look.apply(p)
        style.apply(p)
        p.motion = motion.id
        p.transIn = transIn.id
        p.transOut = transOut.id
        p.bright += bright
        p.contrast *= contrast
        p.sat *= sat
        p.warm += warm
        p.vignette += vignette
        p.grain += grain
        p.sharp = (p.sharp + sharp).coerceAtMost(1.5f)
        p.denoise = (p.denoise + denoise).coerceAtMost(1f)
        p.dur = durSec.coerceAtLeast(0.1f)
        return p
    }

    fun rotatedSrc(): Pair<Int, Int> =
        if (rotation % 180 == 90) Pair(srcH, srcW) else Pair(srcW, srcH)

    fun outSize(): Pair<Int, Int> {
        val (w, h) = rotatedSrc()
        val ar = if (aspect.ratio == 0f) w.toFloat() / h else aspect.ratio
        val short = if (quality == 0) min(w, h) else quality
        var ow: Int
        var oh: Int
        if (ar >= 1f) {
            oh = short
            ow = (short * ar).roundToInt()
        } else {
            ow = short
            oh = (short / ar).roundToInt()
        }
        ow -= ow % 2
        oh -= oh % 2
        return Pair(ow, oh)
    }
}

@UnstableApi
fun rotateFlip(s: EditorState): ScaleAndRotateTransformation =
    ScaleAndRotateTransformation.Builder()
        .setRotationDegrees(s.rotation.toFloat())
        .setScale(if (s.flipH) -1f else 1f, 1f)
        .build()

@UnstableApi
fun previewEffects(s: EditorState, fx: Map<String, Float>): List<Effect> {
    val l = mutableListOf<Effect>()
    if (s.rotation != 0 || s.flipH) l += rotateFlip(s)
    l += UberEffect(fx)
    return l
}

@UnstableApi
class EditorViewModel(app: Application) : AndroidViewModel(app) {
    private val _state = MutableStateFlow(EditorState())
    val state: StateFlow<EditorState> = _state

    private val _thumbs = MutableStateFlow<List<Bitmap>>(emptyList())
    val thumbs: StateFlow<List<Bitmap>> = _thumbs

    private val undoStack = ArrayDeque<EditorState>()
    private val redoStack = ArrayDeque<EditorState>()
    private var lastPush = 0L

    fun set(block: (EditorState) -> EditorState) {
        val old = _state.value
        val new = block(old)
        if (new == old) return
        val now = System.currentTimeMillis()
        if (now - lastPush > 600) {
            undoStack.addLast(old)
            if (undoStack.size > 50) undoStack.removeFirst()
            redoStack.clear()
        }
        lastPush = now
        _state.value = new
    }

    fun undo() {
        val prev = undoStack.removeLastOrNull() ?: return
        val cur = _state.value
        redoStack.addLast(cur)
        _state.value = prev.copy(exporting = cur.exporting, progress = cur.progress)
    }

    fun redo() {
        val next = redoStack.removeLastOrNull() ?: return
        val cur = _state.value
        undoStack.addLast(cur)
        _state.value = next.copy(exporting = cur.exporting, progress = cur.progress)
    }

    private fun loadThumbs(uri: Uri, duration: Long) {
        _thumbs.value = emptyList()
        viewModelScope.launch(Dispatchers.IO) {
            val m = MediaMetadataRetriever()
            val out = mutableListOf<Bitmap>()
            try {
                m.setDataSource(getApplication<Application>(), uri)
                val n = 8
                for (i in 0 until n) {
                    val b = m.getFrameAtTime(duration * 1000L * i / n, MediaMetadataRetriever.OPTION_CLOSEST_SYNC) ?: continue
                    val h = 128
                    val w = (b.width * h / b.height.toFloat()).toInt().coerceAtLeast(1)
                    out += Bitmap.createScaledBitmap(b, w, h, true)
                }
            } catch (e: Exception) {
            } finally {
                m.release()
            }
            _thumbs.value = out.toList()
        }
    }

    fun onVideoPicked(uri: Uri) {
        val r = MediaMetadataRetriever()
        var duration = 0L
        var w = 1920
        var h = 1080
        try {
            r.setDataSource(getApplication(), uri)
            duration = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 1920
            h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 1080
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            if (rot == 90 || rot == 270) { val t = w; w = h; h = t }
        } finally {
            r.release()
        }
        undoStack.clear()
        redoStack.clear()
        _state.value = EditorState(uri = uri, durationMs = duration, srcW = w, srcH = h, trimEndMs = duration)
        loadThumbs(uri, duration)
    }

    fun addCaption(c: Caption) = set { it.copy(captions = it.captions + c) }
    fun removeCaption(c: Caption) = set { it.copy(captions = it.captions - c) }
    fun clearMessage() = _state.update { it.copy(message = null) }

    fun export() {
        val s = _state.value
        val uri = s.uri ?: return
        if (s.exporting) return
        val app = getApplication<Application>()
        val out = File(app.cacheDir, "kz_${System.currentTimeMillis()}.mp4")

        val clipping = MediaItem.ClippingConfiguration.Builder()
            .setStartPositionMs(s.trimStartMs)
            .setEndPositionMs(s.trimEndMs)
            .build()
        val mediaItem = MediaItem.Builder().setUri(uri).setClippingConfiguration(clipping).build()

        val (outW, outH) = s.outSize()
        val outDurSec = (s.trimEndMs - s.trimStartMs) / 1000f / s.speed
        val shifted = s.captions.map {
            it.copy(
                startMs = ((it.startMs - s.trimStartMs) / s.speed).toLong(),
                endMs = ((it.endMs - s.trimStartMs) / s.speed).toLong()
            )
        }

        val video = mutableListOf<Effect>()
        val audio = mutableListOf<AudioProcessor>()
        if (s.speed != 1f) {
            video += SpeedChangeEffect(s.speed)
            val sonic = SonicAudioProcessor()
            sonic.setSpeed(s.speed)
            audio += sonic
        }
        if (s.rotation != 0 || s.flipH) video += rotateFlip(s)
        video += Presentation.createForWidthAndHeight(outW, outH, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP)
        video += UberEffect(s.fxParams(outDurSec).toMap())
        if (shifted.isNotEmpty()) {
            video += OverlayEffect(
                ImmutableList.of(
                    CaptionOverlay(shifted, min(outW, outH) / 14, s.captionStyle.c1.toInt(), s.captionStyle.c2.toInt())
                )
            )
        }

        val edited = EditedMediaItem.Builder(mediaItem)
            .setRemoveAudio(s.mute)
            .setEffects(Effects(audio, video))
            .build()

        val pixels = outW.toLong() * outH
        val bitrate = when {
            pixels >= 3840L * 2160 -> 50_000_000
            pixels >= 2560L * 1440 -> 28_000_000
            pixels >= 1920L * 1080 -> 18_000_000
            pixels >= 1280L * 720 -> 9_000_000
            else -> 6_000_000
        }
        val encoderFactory = DefaultEncoderFactory.Builder(app)
            .setRequestedVideoEncoderSettings(VideoEncoderSettings.Builder().setBitrate(bitrate).build())
            .build()

        val transformer = Transformer.Builder(app)
            .setEncoderFactory(encoderFactory)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    viewModelScope.launch {
                        withContext(Dispatchers.IO) {
                            MediaSaver.saveVideo(app, out)
                            if (shifted.isNotEmpty()) MediaSaver.saveSrt(app, SrtWriter.write(shifted))
                            out.delete()
                        }
                        _state.update { it.copy(exporting = false, progress = 1f, message = "Saved: Movies/KZ Editor") }
                    }
                }

                override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                    _state.update { it.copy(exporting = false, message = "Export failed: ${exportException.errorCodeName}") }
                }
            })
            .build()

        _state.update { it.copy(exporting = true, progress = 0f, message = null) }
        transformer.start(edited, out.absolutePath)

        viewModelScope.launch {
            val holder = ProgressHolder()
            while (_state.value.exporting) {
                if (transformer.getProgress(holder) != Transformer.PROGRESS_STATE_NOT_STARTED) {
                    _state.update { it.copy(progress = holder.progress / 100f) }
                }
                delay(300)
            }
        }
    }
}
