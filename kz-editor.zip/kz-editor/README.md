# kz editor

Quality-first video editor for Android (Kotlin + Jetpack Compose + Media3). One-pass GPU shader for all looks/effects.

## Features (v3: CapCut-style home + editor, timeline, undo/redo)
- **Looks:** Original, HDR, Clear, Ultra Clear, Arctic Blue, Warm Glow, Cinematic, Vivid, Moody, Pastel, Noir, Sunset
- **Effects:** Glitch, RGB Split, VHS, Film Grain, Vignette, Blur, Pixelate, Mirror (H/V/Quad), Glow, B&W, Sepia, Invert, Duotone, Cyberpunk, Vintage
- **Motion:** Zoom In/Out, Pulse, Shake, Drift
- **Transitions (intro/outro):** Fade, Fade White, Wipe, Zoom, Glitch, Flash, Blur, Iris, Pixelate
- **Adjust:** brightness, contrast, saturation, warmth, vignette, grain
- **Pro Enhance (GPU):** denoise (edge-preserving), detail/sharpness, Auto Enhance, upscale to 1440p/4K
- **Edit:** trim, speed 0.25x-3x (audio follows), rotate, flip, mute
- **Captions:** Amharic/any language, 4 styles, burned in + `.srt`
- **Export:** aspect Original/9:16/16:9/1:1/4:5, Source/720p/1080p/2K/4K, hardware encoder, high bitrate

## Build
Push to GitHub -> Actions -> "Build APK" -> download `kz-editor-debug`.

## Not yet (roadmap)
Multi-clip timeline with between-clip transitions, music/audio mixing, auto-captions (Whisper), AI upscaling/frame interpolation (needs ML models), chroma key, PiP/stickers, keyframes, background blur fill.
