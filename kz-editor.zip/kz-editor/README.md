# kz editor

Quality-first video editor for Android (Kotlin + Jetpack Compose + Media3).

## Features
- Visual Enhancer: Original, HDR, Clear, Ultra Clear, Arctic Blue, Warm Glow, Cinematic (GPU color + sharpen), live preview
- Captions (CC): Amharic/any language, 2-style (white + blue) text, burned into video + `.srt` export
- Trim
- Export 720p / 1080p / 4K (H.264, hardware encoder, high bitrate)

## Build
Push to GitHub -> Actions tab -> "Build APK" -> download `kz-editor-debug` artifact.
Or open in Android Studio (Koala+) and run.

## Roadmap
- Auto-captions (Whisper), multi-clip timeline, speed control, music/audio mixing, transitions
